import java.util.Scanner;
class Main{
  public static void main(String[] args) {
    Scanner ler= new Scanner(System.in);
    int tempohora, velokm, autonomia, kmpercorrido, consFinal;
    
    System.out.println("Digite o tempo total da viagem em Horas");
    tempohora=ler.nextInt();
    
    System.out.println("Digite a velocidade média em km/h");
    velokm=ler.nextInt();
    
     System.out.println("Digite a autonomia do veículo em km/l");
    autonomia=ler.nextInt();
    
    kmpercorrido= tempohora*velokm;
    
    consFinal= kmpercorrido/autonomia;
    
    System.out.println("O consumo final do combustível foi: "+consFinal+" litros");
  }
} 
