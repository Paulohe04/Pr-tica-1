import java.util.Scanner;
class Main{
  public static void main(String[] args) {
Scanner entrada = new Scanner (System.in);
			      
			    int cnt=0;
				String vogais= "";
				
		        System.out.println("Escreva um Poema: ");            
		        String poema = entrada.nextLine();
		        
		        poema = poema.toLowerCase();
		        for(int i = 0; i < poema.length(); i++){
		            char c = poema.charAt(i);
		            
		            if(c == 'a' | c == 'e' | c == 'i' | c == 'o' | c == 'u'){
		               
		               vogais= vogais+Character.toString(c);
		               
		            }
		        }
		        if(vogais.contains("a"))
		        	cnt++;
		        if(vogais.contains("e"))
		        	cnt++;
		        if(vogais.contains("i"))
		        	cnt++;
		        if(vogais.contains("o"))
		        	cnt++;
		        if(vogais.contains("u"))
	        	cnt++;
		        System.out.println("No Poema \"" + poema + "\" tem: " + cnt  + " vogais.");
		}
		}