import java.util.Scanner;
class Main{
  public static void main(String[] args) {
    Scanner ler= new Scanner(System.in);
    
    int placa, ano;
    
    System.out.println("Digite a placa do carro");
    placa=ler.nextInt();
    
    System.out.println("Digite o ano do carro");
    ano=ler.nextInt();

    if(ano <= 2010){
      System.out.println("Carro Velho");
    }
    if(ano >= 2011 & ano <= 2021){
       System.out.println("Carro SemiNovo");
    }
    if(ano > 2021){
      System.out.println("Carro Novo");
    }
    
     
  }
}
